﻿using OnlineStudentManagementSystem.Models;
using System.ComponentModel.DataAnnotations;

namespace OnlineStudentManagementSystem.DTO
{
    public class SubjectDTO
    {
        [Required]
        public string SubjectName { get; set; } 
       
        
    }
}
