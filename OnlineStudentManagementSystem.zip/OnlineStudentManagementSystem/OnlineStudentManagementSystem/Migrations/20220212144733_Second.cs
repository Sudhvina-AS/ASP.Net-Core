﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace OnlineStudentManagementSystem.Migrations
{
    public partial class Second : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "EnrollId",
                table: "SubjectReportCards",
                newName: "SubjectReportCardId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SubjectReportCardId",
                table: "SubjectReportCards",
                newName: "EnrollId");
        }
    }
}
