import React, { setState, Component } from "react"; 

import AddressCodes from "../DbServices/AddressCodes"; 
class UpdateAddressCode extends React.Component { 
  constructor() { 
    super(); 
    this.state = { 
      AddressCodes: [], 
      addressCodeId: "", 
      city: "", 
      state: "", 
      zipCode: "", 
      
    }; 
    this.selectedId = 0; 
    this.UpdateAddressCode = this.UpdateAddressCode.bind(this); 
  } 
  onChange(event) { 
    this.setState({ [event.target.name]: event.target.value }); 
  } 
 
  UpdateAddressCode() { 
    let obj = {}; 
    obj.addressCodeId = this.state.addressCodeId; 
    obj.city = this.state.city; 
    obj.state = this.state.state; 
    obj.zipCode= this.state.zipCode; 
    
     
 
    AddressCodes.updateAddressCode(this.addressCodeId, obj).then((resData) => { 
      this.setState({ 
        result: resData.data.result, 
        addressCodeId: "", 
        city: "", 
        state: "", 
        zipCode:"", 
        
      }); 
      this.getData(); 
    }); 
  } 
  render() { 
    return ( 
      <div> 
        <center> 
          <h1>Update Details</h1> 
        </center> 
        <div className="form"> 
          <form onSubmit={UpdateAddressCode}> 
            <label>addressCodeId</label> 
            <input
						    placeholder="Enter addressCodeId"
							type="text"
							name="addressCodeId"
							value={this.state.addressCodeId}
							onChange={this.input_change}
							required={true}
						/>
			 <label>city</label> 
            <input 
              type="text" 
              name="city" 
              value={this.state.city} 
              className="form-control" 
              placeholder=" Enter addressCode Id" 
              required 
              onChange={this.input_change} 
            /> 
			 <label>state</label> 
            <input 
              type="text" 
              name="state" 
              value={this.state.state} 
              className="form-control" 
              placeholder=" Enter addressCode Id" 
              required 
              onChange={this.input_change} 
            /> 
			 <label>zipCode</label> 
            <input 
              type="text" 
              name="zipCode" 
              value={this.state.zipCode} 
              className="form-control" 
              placeholder=" Enter addressCode Id" 
              required 
              onChange={this.input_change} 
            /> 
            
           
 
           
            <button onClick={this.UpdateAddressCode}>Update</button> 
             
          </form> 
        </div> 
      </div> 
    ); 
  } 
} 
export default UpdateAddressCode;