import React, { Component } from 'react'
import axios from 'axios'
import { Link } from "react-router-dom";
export class AddressCodes extends Component {
	constructor(props) {
		super(props)

		this.state = {
			city: '',
			state: '',
            zipCode:''
		}
	}

	changeHandler = e => {
		this.setState({ [e.target.name]: e.target.value })
	}

	submitHandler = e => {
		e.preventDefault()
		console.log(this.state)
		axios
			.post('https://localhost:44384/api/AddressCodes', this.state)
			.then(response => {
				console.log(response)
			})
			.catch(error => {
				console.log(error)
			})
	}

	render() {
		const {  city, state,zipCode } = this.state
		return (
            <div class="main-block">
        <h2 style={{color: "black"}}>AddressCode</h2>
			<div>
				<form onSubmit={this.submitHandler}>
					<div>
                    <lable className="txt" style={{color: "Black"}}>Enter City:  </lable>
						<input
						    placeholder="Enter City"
							type="text"
							name="city"
							value={city}
							onChange={this.changeHandler}
							required={true}
						/>
					</div>
                    <br></br>
					<div>
                    <lable className="txt" style={{color: "Black"}}>Enter State:  </lable>
						<input
						    placeholder="Enter State"
							type="text"
							name="state"
							value={state}
							onChange={this.changeHandler}
							required={true}
						/>
					</div>
                    <br></br>
                    <div>
                    <lable className="txt" style={{color: "Black"}}>Enter ZipCode:  </lable>
						<input
						    placeholder="Enter ZipCode"
							type="text"
							name="zipCode"
							value={zipCode}
							onChange={this.changeHandler}
							required={true}
						/>
					</div>
                    <br></br>
					<button type="submit">Submit</button>&nbsp;
                    <button>
					<Link to="AddressCodeTable" className="formFieldLink">

					<a href="/AddressCodeTable">View</a></Link>
					</button>
					
				</form>
                </div>
			</div>
		)
	}
}

export default AddressCodes;