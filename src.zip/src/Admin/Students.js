import React, { Component } from 'react'
import axios from 'axios'
import { Link } from "react-router-dom";
import {Card, CardBody, CardHeader, Col, Row, Table} from 'reactstrap';

   
export class CreateStudent extends Component {
	constructor(props) {
		super(props)

		this.state = {
            studentName: '',
            dob:'',
			city: '',
			state: '',
            zipCode:'',
            courseName:''
		}
	}

	changeHandler = e => {
		this.setState({ [e.target.name]: e.target.value })
	}

	submitHandler = e => {
		e.preventDefault()
		console.log(this.state)
		axios
			.post('https://localhost:44384/api/Students+/AddressCodes+/Course', this.state)

			.then(response => {
				
	 
				console.log(response)
			})
			.catch(error => {
				console.log(error)
			})
	}

	render() {
		const { studentName,dob, city, state,zipCode,courseName } = this.state
		return (
			
			<div class="main-block">
        <h2 style={{color: "black"}}>Add Student</h2>

			<div>
				<form onSubmit={this.submitHandler}>
					<div>
						
                    <lable className="txt" style={{color: "Black"}}>Enter Students Name:  </lable>
						<input
							type="text"
							placeholder='Enter Student Name'
							name="studentName"
							required={true}
							value={studentName}
							onChange={this.changeHandler}
						/>
					</div>
                    <br></br>

                    <div>
                    <lable className="txt" style={{color: "Black"}}>Enter Date of Birth:  </lable>
						<input
							type="date"
							placeholder='Enter Date Of Birth'
							name="dob"
							required={true}
							value={dob}
							onChange={this.changeHandler}
						/>
					</div>   
                    <br></br>
                    <div>
                    <lable className="txt" style={{color: "Black"}}>Enter City:  </lable>
						<input
						    placeholder="Enter City"
							type="text"
							name="city"
							value={city}
							onChange={this.changeHandler}
							required={true}
						/>
					</div>
                    <br></br>
					<div>
                    <lable className="txt" style={{color: "Black"}}>Enter State:  </lable>
						<input
							type="text"
							placeholder='Enter State'
							name="state"
							value={state}
							onChange={this.changeHandler}
						/>
					</div>
                    <br></br>
                    <div>
                    <lable className="txt" style={{color: "Black"}}>Enter Zip Code:  </lable>
						<input
							type="text"
							placeholder='Enter Zip Code'
							name="zipCode"
							value={zipCode}
							onChange={this.changeHandler}
						/>

					</div>
                    <br></br>
                    <div>
                    <lable className="txt" style={{color: "Black"}}>Enter Course:  </lable>
						<input
							type="text"
							placeholder='Enter Course Name'
							name="courseName"
							value={courseName}
							onChange={this.changeHandler}
						/>

					</div>
                    <br></br> 
                   
					<button type="submit">Submit</button>&nbsp;
                   
					
					<button>
					<Link to="StudentsTable" className="formFieldLink">

					<a href="/StudentsTable">View</a></Link>
					</button>
				   
				  

				</form>
			</div>
			</div>
		)
	}
}

export default CreateStudent;
